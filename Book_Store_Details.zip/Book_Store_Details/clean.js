const fs = require('fs');
const path = require('path');

const walkSync = (dir, filelist = []) => {
  fs.readdirSync(dir).forEach(file => {
    const dirFile = path.join(dir, file);
    try {
      filelist = walkSync(dirFile, filelist);
    } catch (err) {
      if (err.code === 'ENOTDIR' || err.code === 'EBUSY') filelist.push(dirFile);
    }
  });
  return filelist;
};

const removeCommentsAndEmojis = (filePath) => {
    let content = fs.readFileSync(filePath, 'utf8');
    
    // Remove emojis
    content = content.replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F1E0}-\u{1F1FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F900}-\u{1F9FF}\u{1FA70}-\u{1FAFF}]/gu, '');

    // Remove HTML comments
    if (filePath.endsWith('.ejs') || filePath.endsWith('.html')) {
        content = content.replace(/<!--[\s\S]*?-->/g, '');
    }

    // Remove CSS comments
    if (filePath.endsWith('.css')) {
        content = content.replace(/\/\*[\s\S]*?\*\//g, '');
    }

    // Remove JS comments (basic)
    if (filePath.endsWith('.js') && !filePath.includes('clean.js')) {
        content = content.replace(/\/\/.*/g, ''); // single line
        content = content.replace(/\/\*[\s\S]*?\*\//g, ''); // multi line
    }

    // cleanup empty lines
    content = content.replace(/^\s*[\r\n]/gm, '');

    fs.writeFileSync(filePath, content, 'utf8');
};

const directoryPath = path.join(__dirname, 'BookStoreManagement');
const files = walkSync(directoryPath);

files.forEach(file => {
    if (!file.includes('node_modules') && !file.includes('.git') && !file.endsWith('.png') && !file.endsWith('.jpg') && !file.endsWith('.lock') && !file.endsWith('.json')) {
        if (file.endsWith('.js') || file.endsWith('.ejs') || file.endsWith('.css')) {
            removeCommentsAndEmojis(file);
            console.log('Cleaned:', file);
        }
    }
});

console.log('Done cleaning');
