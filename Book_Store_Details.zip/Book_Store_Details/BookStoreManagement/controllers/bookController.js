const Book = require('../models/Book');
const fs = require('fs');
const path = require('path');
exports.getDashboard = async (req, res) => {
    try {
        const totalBooks = await Book.countDocuments();
        const books = await Book.find().sort({ createdAt: -1 }).limit(5);
        const totalValue = await Book.aggregate([
            { $group: { _id: null, total: { $sum: { $multiply: ['$price', '$quantity'] } } } }
        ]);
        const inventoryValue = totalValue.length > 0 ? totalValue[0].total : 0;
        res.render('index', {
            totalBooks,
            recentBooks: books,
            inventoryValue,
            success: req.flash('success'),
            error: req.flash('error')
        });
    } catch (err) {
        req.flash('error', 'Failed to load dashboard');
        res.redirect('/');
    }
};
exports.getAllBooks = async (req, res) => {
    try {
        const books = await Book.find().sort({ createdAt: -1 });
        res.render('viewBooks', {
            books,
            success: req.flash('success'),
            error: req.flash('error')
        });
    } catch (err) {
        req.flash('error', 'Failed to fetch books');
        res.redirect('/');
    }
};
exports.getAddBook = (req, res) => {
    res.render('addBook', {
        success: req.flash('success'),
        error: req.flash('error')
    });
};
exports.postAddBook = async (req, res) => {
    try {
        const { title, author, category, price, quantity, description } = req.body;
        const image = req.file ? '/uploads/' + req.file.filename : '';
        const book = new Book({ title, author, category, price, quantity, description, image });
        await book.save();
        req.flash('success', 'Book added successfully!');
        res.redirect('/books');
    } catch (err) {
        req.flash('error', 'Failed to add book. Please check all fields.');
        res.redirect('/books/add');
    }
};
exports.getEditBook = async (req, res) => {
    try {
        const book = await Book.findById(req.params.id);
        if (!book) {
            req.flash('error', 'Book not found');
            return res.redirect('/books');
        }
        res.render('editBook', {
            book,
            success: req.flash('success'),
            error: req.flash('error')
        });
    } catch (err) {
        req.flash('error', 'Failed to load book');
        res.redirect('/books');
    }
};
exports.postEditBook = async (req, res) => {
    try {
        const { title, author, category, price, quantity, description } = req.body;
        const book = await Book.findById(req.params.id);
        if (!book) {
            req.flash('error', 'Book not found');
            return res.redirect('/books');
        }
        let image = book.image;
        if (req.file) {
            if (book.image) {
                const oldPath = path.join(__dirname, '..', 'public', book.image);
                if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
            }
            image = '/uploads/' + req.file.filename;
        }
        book.title = title;
        book.author = author;
        book.category = category;
        book.price = price;
        book.quantity = quantity;
        book.description = description;
        book.image = image;
        await book.save();
        req.flash('success', 'Book updated successfully!');
        res.redirect('/books');
    } catch (err) {
        req.flash('error', 'Failed to update book');
        res.redirect('/books/edit/' + req.params.id);
    }
};
exports.deleteBook = async (req, res) => {
    try {
        const book = await Book.findById(req.params.id);
        if (!book) {
            req.flash('error', 'Book not found');
            return res.redirect('/books');
        }
        if (book.image) {
            const imgPath = path.join(__dirname, '..', 'public', book.image);
            if (fs.existsSync(imgPath)) fs.unlinkSync(imgPath);
        }
        await Book.findByIdAndDelete(req.params.id);
        req.flash('success', 'Book deleted successfully!');
        res.redirect('/books');
    } catch (err) {
        req.flash('error', 'Failed to delete book');
        res.redirect('/books');
    }
};
